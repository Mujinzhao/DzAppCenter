<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once dirname(__FILE__).'/class/env.class.php';

class mobileplugin_demoapp
{
    function common()
    {
    }
}

