/* japp.js, (c) 2016 mawentao */

var conf={loglevel:3},JApp=function(n){this.init=function(){require.config({baseUrl:n,packages:[{name:"frame",location:"frame",main:"main"}]}),require(["jappengine"],function(n,e,i,a){n.start()})}};